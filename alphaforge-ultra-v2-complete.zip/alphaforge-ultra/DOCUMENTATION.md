# AlphaForge Ultra - Complete Documentation

## Table of Contents
1. [Quick Start](#quick-start)
2. [Architecture](#architecture)
3. [AI Agents](#ai-agents)
4. [API Reference](#api-reference)
5. [Deployment](#deployment)

## Quick Start

### Prerequisites
- Node.js 18+
- OpenAI API key
- (Optional) Docker for containerized deployments

### Installation
```bash
# Clone and setup
git clone <repo>
cd alphaforge-ultra
npm install
cp .env.example .env
# Edit .env with your OPENAI_API_KEY
npm start
```

## Architecture

### Multi-Agent System
The orchestrator manages 11 specialized agents that work in parallel:

```
User Request
    ↓
Orchestrator
    ↓
┌─────────────┬─────────────┬─────────────┐
↓             ↓             ↓             ↓
Research    Architect    Designer    Security
    ↓             ↓             ↓             ↓
    └─────────────┴─────────────┴─────────────┘
                    ↓
            Code Generator
                    ↓
    ┌───────────────┼───────────────┐
    ↓               ↓               ↓
Debugger        Tester         Reviewer
    └───────────────┴───────────────┘
                    ↓
            Performance
                    ↓
            Documentation
                    ↓
                Deploy
```

### TAO Loop Pattern
Each agent follows the TAO (Think-Act-Observe) loop:
1. **Think**: Analyze task and plan approach
2. **Act**: Execute using available tools
3. **Observe**: Review results and adapt

## AI Agents

### 1. ArchitectAgent
- **Role**: System design and architecture
- **Tools**: File system, research
- **Output**: Architecture diagrams, tech stack recommendations

### 2. CodeGeneratorAgent
- **Role**: Write production code
- **Tools**: File system, code templates
- **Output**: Complete, documented code

### 3. DebugAgent
- **Role**: Fix bugs and errors
- **Tools**: Code execution, error analysis
- **Output**: Patched code, error explanations

### 4. TestAgent
- **Role**: Generate and run tests
- **Tools**: Test frameworks, code coverage
- **Output**: Test suites, coverage reports

### 5. ReviewAgent
- **Role**: Code review and quality
- **Tools**: Static analysis, best practices
- **Output**: Review comments, improvement suggestions

### 6. DeployAgent
- **Role**: Deploy to production
- **Tools**: Docker, cloud APIs
- **Output**: Live URLs, deployment configs

### 7. ResearchAgent
- **Role**: Technology research
- **Tools**: Web search, documentation
- **Output**: Research reports, recommendations

### 8. DesignAgent
- **Role**: UI/UX design
- **Tools**: CSS generation, mockup tools
- **Output**: Designs, style guides

### 9. SecurityAgent
- **Role**: Security auditing
- **Tools**: Vulnerability scanners
- **Output**: Security reports, fixes

### 10. PerformanceAgent
- **Role**: Optimization
- **Tools**: Profiling, benchmarking
- **Output**: Optimized code, performance reports

### 11. DocumentationAgent
- **Role**: Create documentation
- **Tools**: Doc generators
- **Output**: README, API docs, guides

## API Reference

### REST Endpoints

#### Create Project
```http
POST /api/projects
Content-Type: application/json

{
  "prompt": "Build a SaaS dashboard",
  "options": {
    "mode": "autonomous",
    "autonomy": "high"
  }
}
```

#### Get Project Status
```http
GET /api/projects/:id
```

#### Get Project Files
```http
GET /api/projects/:id/files
```

#### Update File
```http
PUT /api/projects/:id/files/path/to/file.js
Content-Type: application/json

{
  "content": "console.log('Hello');"
}
```

#### Execute Code
```http
POST /api/execute
Content-Type: application/json

{
  "code": "console.log('Hello World')",
  "language": "javascript"
}
```

### WebSocket Events

#### Client → Server
- `subscribe`: Subscribe to project updates
- `unsubscribe`: Unsubscribe from project
- `cursor:update`: Update cursor position
- `operation`: Send edit operation
- `chat:message`: Send chat message

#### Server → Client
- `project:created`: New project created
- `project:log`: Log message from agent
- `project:complete`: Project finished
- `agent:progress`: Agent status update
- `user:joined`: User joined room
- `cursor:update`: Cursor position update

## Deployment

### Static Sites
Automatically deployed to `/deployments/static/`

### Containerized Apps
Docker containers with auto-scaling support

### Environment Variables
- `OPENAI_API_KEY`: Required for AI functionality
- `PORT`: Server port (default: 3000)
- `NODE_ENV`: Environment (development/production)
- `REDIS_URL`: Optional Redis for scaling

## Scaling

### Horizontal Scaling
- Use Redis adapter for Socket.io
- Load balancer for multiple server instances
- Shared storage for projects

### Vertical Scaling
- Increase memory limits for agents
- Use GPT-4 for better code quality
- Enable caching for repeated tasks

## Security

### Sandboxing
- Code execution in isolated temp directories
- Resource limits (CPU, memory, time)
- No network access in sandbox (optional)

### Authentication
- JWT-based auth (add your own)
- API key management
- Rate limiting recommended

## Troubleshooting

### Common Issues

**OpenAI API errors**
- Check API key in .env
- Verify API quota
- Check model availability

**Port already in use**
- Change PORT in .env
- Kill existing process: `kill $(lsof -t -i:3000)`

**Memory errors**
- Increase Node memory: `NODE_OPTIONS="--max-old-space-size=4096"`
- Reduce maxIterations in agents

## Contributing

1. Fork the repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Create Pull Request

## License

MIT License - See LICENSE file
