/**
 * AlphaForge Ultra - Frontend Application
 * Real-time collaboration, Monaco Editor, Multi-Agent monitoring
 */

// Global state
const state = {
  socket: null,
  editor: null,
  currentProject: null,
  openFiles: new Map(),
  activeFile: null,
  projects: [],
  agents: new Map(),
  terminalHistory: [],
  isSidebarCollapsed: false
};

// Initialize application
document.addEventListener('DOMContentLoaded', async () => {
  await initializeApp();
});

async function initializeApp() {
  // Show loading screen
  showLoading();

  // Initialize Socket.io connection
  initializeSocket();

  // Initialize Monaco Editor
  await initializeMonaco();

  // Load initial data
  await loadProjects();

  // Setup event listeners
  setupEventListeners();

  // Hide loading screen
  setTimeout(() => {
    hideLoading();
  }, 1500);
}

function showLoading() {
  document.getElementById('loading-screen').classList.remove('hidden');
  document.getElementById('app').classList.add('hidden');
}

function hideLoading() {
  document.getElementById('loading-screen').classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');
}

// ========== Socket.io Connection ==========
function initializeSocket() {
  state.socket = io();

  state.socket.on('connect', () => {
    console.log('✅ Connected to server');
    updateConnectionStatus(true);
  });

  state.socket.on('disconnect', () => {
    console.log('❌ Disconnected from server');
    updateConnectionStatus(false);
  });

  // Project events
  state.socket.on('project:created', (data) => {
    console.log('Project created:', data);
    addActivityLog('system', 'Project created: ' + data.projectId);
  });

  state.socket.on('project:log', (data) => {
    addActivityLog('system', data.log.message);
    updateCreationStep(data.log.message);
  });

  state.socket.on('project:complete', (data) => {
    handleProjectComplete(data);
  });

  state.socket.on('project:error', (data) => {
    handleProjectError(data);
  });

  // Agent events
  state.socket.on('agent:progress', (data) => {
    updateAgentStatus(data.agent, 'running', data);
    addActivityLog(data.agent, data.status + ': ' + (data.tool || data.message));
  });

  state.socket.on('agent:complete', (data) => {
    updateAgentStatus(data.agent, 'complete', data);
    addActivityLog(data.agent, 'Task completed');
  });

  state.socket.on('agent:error', (data) => {
    updateAgentStatus(data.agent, 'error', data);
    addActivityLog(data.agent, 'Error: ' + data.error);
  });
}

function updateConnectionStatus(connected) {
  const dot = document.querySelector('.status-dot');
  const text = document.querySelector('.connection-status span:last-child');

  if (connected) {
    dot.classList.remove('disconnected');
    text.textContent = 'Connected';
  } else {
    dot.classList.add('disconnected');
    text.textContent = 'Disconnected';
  }
}

// ========== Monaco Editor ==========
async function initializeMonaco() {
  return new Promise((resolve) => {
    require.config({ 
      paths: { 
        'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.44.0/min/vs' 
      } 
    });

    require(['vs/editor/editor.main'], () => {
      // Configure theme
      monaco.editor.defineTheme('alphaforge-dark', {
        base: 'vs-dark',
        inherit: true,
        rules: [
          { token: 'comment', foreground: '6e7681', fontStyle: 'italic' },
          { token: 'keyword', foreground: 'ff7b72' },
          { token: 'string', foreground: 'a5d6ff' },
          { token: 'number', foreground: '79c0ff' },
          { token: 'tag', foreground: '7ee787' },
          { token: 'attribute.name', foreground: 'd2a8ff' }
        ],
        colors: {
          'editor.background': '#0d1117',
          'editor.foreground': '#e6edf3',
          'editor.lineHighlightBackground': '#161b22',
          'editor.selectionBackground': '#264f78',
          'editor.inactiveSelectionBackground': '#264f7855'
        }
      });

      state.editor = monaco.editor.create(document.getElementById('monaco-editor'), {
        value: '// Welcome to AlphaForge Ultra\n// Create a project to start coding\n',
        language: 'javascript',
        theme: 'alphaforge-dark',
        automaticLayout: true,
        minimap: { enabled: true },
        fontSize: 14,
        fontFamily: 'Consolas, Monaco, monospace',
        scrollBeyondLastLine: false,
        roundedSelection: false,
        padding: { top: 16 },
        folding: true,
        renderLineHighlight: 'line',
        matchBrackets: 'always',
        tabSize: 2,
        insertSpaces: true
      });

      // Add command palette shortcut
      state.editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyP, () => {
        state.editor.getAction('editor.action.quickCommand').run();
      });

      // Auto-save on change
      let saveTimeout;
      state.editor.onDidChangeModelContent(() => {
        clearTimeout(saveTimeout);
        saveTimeout = setTimeout(() => {
          if (state.activeFile) {
            saveFile(state.activeFile, state.editor.getValue());
          }
        }, 1000);
      });

      resolve();
    });
  });
}

// ========== Project Management ==========
async function createProject() {
  const prompt = document.getElementById('main-prompt').value.trim();
  const mode = document.getElementById('build-mode').value;

  if (!prompt) {
    alert('Please describe what you want to build');
    return;
  }

  // Show creation modal
  showCreationModal();

  try {
    const response = await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt,
        options: { mode, autonomy: 'high' }
      })
    });

    const data = await response.json();

    if (data.success) {
      state.currentProject = data.projectId;

      // Subscribe to project updates
      state.socket.emit('subscribe', data.projectId);

      // Start monitoring
      startProjectMonitoring(data.projectId);

      // Switch to editor view after delay
      setTimeout(() => {
        hideCreationModal();
        showView('editor');
        loadProjectFiles(data.projectId);
      }, 3000);
    } else {
      hideCreationModal();
      alert('Error: ' + data.error);
    }
  } catch (error) {
    console.error('Create project error:', error);
    hideCreationModal();
    alert('Failed to create project');
  }
}

function showCreationModal() {
  document.getElementById('modal-creating').classList.remove('hidden');
  updateCreationProgress(0);
}

function hideCreationModal() {
  document.getElementById('modal-creating').classList.add('hidden');
}

function updateCreationStep(message) {
  const steps = document.getElementById('creation-steps');
  const stepDiv = document.createElement('div');
  stepDiv.className = 'step active';
  stepDiv.innerHTML = `
    <i class="fas fa-circle-notch fa-spin"></i>
    <span>${message}</span>
  `;
  steps.appendChild(stepDiv);

  // Auto-scroll to bottom
  steps.scrollTop = steps.scrollHeight;
}

function updateCreationProgress(percent) {
  document.getElementById('creation-progress').style.width = percent + '%';
}

async function loadProjects() {
  try {
    const response = await fetch('/api/projects');
    const data = await response.json();

    state.projects = data.projects || [];
    renderProjectList();
  } catch (error) {
    console.error('Load projects error:', error);
  }
}

function renderProjectList() {
  const container = document.getElementById('project-list');
  container.innerHTML = '';

  state.projects.forEach(project => {
    const item = document.createElement('button');
    item.className = 'nav-item';
    item.innerHTML = `
      <i class="fas fa-folder"></i>
      <span>${project.prompt.substring(0, 30)}...</span>
    `;
    item.onclick = () => loadProject(project.id);
    container.appendChild(item);
  });
}

async function loadProject(projectId) {
  state.currentProject = projectId;

  try {
    const response = await fetch(`/api/projects/${projectId}`);
    const project = await response.json();

    showView('editor');
    loadProjectFiles(projectId);

    // Subscribe to updates
    state.socket.emit('subscribe', projectId);
  } catch (error) {
    console.error('Load project error:', error);
  }
}

async function loadProjectFiles(projectId) {
  try {
    const response = await fetch(`/api/projects/${projectId}/files`);
    const data = await response.json();

    renderFileTree(data.files);

    // Open first file if none open
    if (state.openFiles.size === 0 && Object.keys(data.files).length > 0) {
      const firstFile = Object.keys(data.files)[0];
      openFile(firstFile, data.files[firstFile]);
    }
  } catch (error) {
    console.error('Load files error:', error);
  }
}

function renderFileTree(files) {
  const container = document.getElementById('file-tree');
  container.innerHTML = '';

  const tree = buildFileTree(files);
  renderTreeNode(container, tree, '');
}

function buildFileTree(files) {
  const tree = {};

  Object.keys(files).forEach(path => {
    const parts = path.split('/');
    let current = tree;

    parts.forEach((part, index) => {
      if (index === parts.length - 1) {
        current[part] = { type: 'file', path };
      } else {
        current[part] = current[part] || { type: 'folder', children: {} };
        current = current[part].children;
      }
    });
  });

  return tree;
}

function renderTreeNode(container, node, path) {
  const sorted = Object.entries(node).sort((a, b) => {
    if (a[1].type === 'folder' && b[1].type === 'file') return -1;
    if (a[1].type === 'file' && b[1].type === 'folder') return 1;
    return a[0].localeCompare(b[0]);
  });

  sorted.forEach(([name, data]) => {
    const item = document.createElement('div');
    item.className = 'file-item';

    if (data.type === 'folder') {
      item.innerHTML = `
        <div class="folder-header" onclick="toggleFolder(this)">
          <i class="fas fa-chevron-right"></i>
          <i class="fas fa-folder"></i>
          <span>${name}</span>
        </div>
        <div class="folder-children hidden"></div>
      `;
      container.appendChild(item);

      const childrenContainer = item.querySelector('.folder-children');
      renderTreeNode(childrenContainer, data.children, path + name + '/');
    } else {
      const filePath = data.path || path + name;
      item.innerHTML = `
        <div class="file-header" onclick="openFileByPath('${filePath}')">
          <i class="fas ${getFileIcon(name)}"></i>
          <span>${name}</span>
        </div>
      `;
      container.appendChild(item);
    }
  });
}

function getFileIcon(filename) {
  if (filename.endsWith('.js')) return 'fa-js';
  if (filename.endsWith('.html')) return 'fa-html5';
  if (filename.endsWith('.css')) return 'fa-css3';
  if (filename.endsWith('.json')) return 'fa-code';
  if (filename.endsWith('.md')) return 'fa-markdown';
  return 'fa-file-code';
}

function toggleFolder(header) {
  const children = header.nextElementSibling;
  const icon = header.querySelector('.fa-chevron-right');

  children.classList.toggle('hidden');
  icon.style.transform = children.classList.contains('hidden') ? 'rotate(0deg)' : 'rotate(90deg)';
}

async function openFileByPath(filePath) {
  try {
    const projectId = state.currentProject;
    const response = await fetch(`/api/projects/${projectId}/files`);
    const data = await response.json();

    if (data.files[filePath]) {
      openFile(filePath, data.files[filePath]);
    }
  } catch (error) {
    console.error('Open file error:', error);
  }
}

function openFile(filePath, content) {
  // Add to open files
  state.openFiles.set(filePath, { content, modified: false });
  state.activeFile = filePath;

  // Update tabs
  renderTabs();

  // Update editor
  const language = getLanguageFromPath(filePath);
  monaco.editor.setModelLanguage(state.editor.getModel(), language);
  state.editor.setValue(content);
}

function renderTabs() {
  const container = document.getElementById('editor-tabs');
  container.innerHTML = '';

  state.openFiles.forEach((data, filePath) => {
    const tab = document.createElement('button');
    tab.className = 'editor-tab' + (filePath === state.activeFile ? ' active' : '');
    tab.innerHTML = `
      <i class="fas ${getFileIcon(filePath)}"></i>
      <span>${filePath.split('/').pop()}${data.modified ? ' *' : ''}</span>
      <i class="fas fa-times close" onclick="closeFile(event, '${filePath}')"></i>
    `;
    tab.onclick = () => switchToFile(filePath);
    container.appendChild(tab);
  });
}

function switchToFile(filePath) {
  const data = state.openFiles.get(filePath);
  if (data) {
    state.activeFile = filePath;
    const language = getLanguageFromPath(filePath);
    monaco.editor.setModelLanguage(state.editor.getModel(), language);
    state.editor.setValue(data.content);
    renderTabs();
  }
}

function closeFile(event, filePath) {
  event.stopPropagation();
  state.openFiles.delete(filePath);

  if (state.activeFile === filePath) {
    const remaining = Array.from(state.openFiles.keys());
    if (remaining.length > 0) {
      switchToFile(remaining[0]);
    } else {
      state.activeFile = null;
      state.editor.setValue('// Select a file to edit');
    }
  }

  renderTabs();
}

async function saveFile(filePath, content) {
  try {
    const projectId = state.currentProject;
    await fetch(`/api/projects/${projectId}/files/${filePath}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content })
    });

    const data = state.openFiles.get(filePath);
    if (data) {
      data.content = content;
      data.modified = false;
      renderTabs();
    }
  } catch (error) {
    console.error('Save file error:', error);
  }
}

function getLanguageFromPath(filePath) {
  if (filePath.endsWith('.js')) return 'javascript';
  if (filePath.endsWith('.ts')) return 'typescript';
  if (filePath.endsWith('.html')) return 'html';
  if (filePath.endsWith('.css')) return 'css';
  if (filePath.endsWith('.json')) return 'json';
  if (filePath.endsWith('.md')) return 'markdown';
  if (filePath.endsWith('.py')) return 'python';
  return 'plaintext';
}

// ========== UI Functions ==========
function showView(viewName) {
  // Hide all views
  document.querySelectorAll('.view').forEach(view => {
    view.classList.remove('active');
  });

  // Show selected view
  document.getElementById(`view-${viewName}`).classList.add('active');

  // Update nav
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.remove('active');
  });

  // Update title
  const titles = {
    'home': 'Create New Project',
    'editor': 'Code Editor',
    'templates': 'Project Templates'
  };
  document.getElementById('page-title').textContent = titles[viewName] || 'AlphaForge';
}

function toggleSidebar() {
  state.isSidebarCollapsed = !state.isSidebarCollapsed;
  document.querySelector('.sidebar').classList.toggle('collapsed', state.isSidebarCollapsed);
}

function setPrompt(text) {
  document.getElementById('main-prompt').value = text;
  document.getElementById('main-prompt').focus();
}

function switchPanel(panelName) {
  // Update tabs
  document.querySelectorAll('.panel-tab').forEach(tab => {
    tab.classList.remove('active');
  });
  event.target.closest('.panel-tab').classList.add('active');

  // Update content
  document.querySelectorAll('.panel-section').forEach(section => {
    section.classList.remove('active');
  });
  document.getElementById(`panel-${panelName}`).classList.add('active');

  // Refresh preview if needed
  if (panelName === 'preview') {
    refreshPreview();
  }
}

function refreshPreview() {
  const frame = document.getElementById('preview-frame');
  if (state.currentProject) {
    // In real implementation, this would load the deployed URL
    frame.src = `about:blank`;
  }
}

// ========== Terminal ==========
function runTerminal() {
  const input = document.getElementById('terminal-cmd');
  const command = input.value.trim();

  if (!command) return;

  addTerminalOutput(`$ ${command}`, 'command');

  // Execute command
  executeTerminalCommand(command);

  input.value = '';
}

async function executeTerminalCommand(command) {
  try {
    const response = await fetch('/api/execute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: command, language: 'bash' })
    });

    const data = await response.json();

    if (data.output) {
      addTerminalOutput(data.output, 'output');
    }
    if (data.error) {
      addTerminalOutput(data.error, 'error');
    }
  } catch (error) {
    addTerminalOutput(error.message, 'error');
  }
}

function addTerminalOutput(text, type) {
  const terminal = document.getElementById('terminal-output');
  const line = document.createElement('div');
  line.className = `terminal-line ${type}`;
  line.textContent = text;
  terminal.appendChild(line);
  terminal.scrollTop = terminal.scrollHeight;
}

// ========== Activity Log ==========
function addActivityLog(agent, message) {
  const feed = document.getElementById('activity-feed');

  // Remove empty state
  const empty = feed.querySelector('.activity-empty');
  if (empty) empty.remove();

  const item = document.createElement('div');
  item.className = 'activity-item';

  const icons = {
    'architect': 'fa-drafting-compass',
    'codegen': 'fa-code',
    'debugger': 'fa-bug',
    'tester': 'fa-vial',
    'designer': 'fa-paint-brush',
    'system': 'fa-info-circle'
  };

  const time = new Date().toLocaleTimeString();

  item.innerHTML = `
    <div class="activity-icon ${agent}">
      <i class="fas ${icons[agent] || 'fa-robot'}"></i>
    </div>
    <div class="activity-content">
      <div class="activity-header">
        <strong>${agent.charAt(0).toUpperCase() + agent.slice(1)}</strong>
        <span class="activity-time">${time}</span>
      </div>
      <div class="activity-message">${message}</div>
    </div>
  `;

  feed.insertBefore(item, feed.firstChild);

  // Keep only last 50 items
  while (feed.children.length > 50) {
    feed.removeChild(feed.lastChild);
  }
}

function updateAgentStatus(agent, status, data) {
  const agentEl = document.querySelector(`[data-agent="${agent}"] .agent-dot`);
  if (agentEl) {
    agentEl.className = `agent-dot ${status}`;
  }
}

// ========== Templates ==========
function useTemplate(template) {
  const templates = {
    'react-app': 'Build a React application with Vite, Tailwind CSS, React Router, and modern hooks pattern',
    'node-api': 'Create a Node.js REST API with Express, MongoDB, JWT authentication, and CRUD operations',
    'nextjs-fullstack': 'Build a full-stack Next.js application with API routes, database, and authentication',
    'python-ml': 'Create a Python machine learning API with Flask, scikit-learn, and data visualization'
  };

  setPrompt(templates[template]);
  showView('home');
}

// ========== Project Monitoring ==========
function startProjectMonitoring(projectId) {
  const interval = setInterval(async () => {
    try {
      const response = await fetch(`/api/projects/${projectId}`);
      const project = await response.json();

      if (project.status === 'completed' || project.status === 'error') {
        clearInterval(interval);
      }

      // Update progress
      const progress = calculateProgress(project);
      updateCreationProgress(progress);

    } catch (error) {
      console.error('Monitoring error:', error);
    }
  }, 2000);
}

function calculateProgress(project) {
  const phases = ['research', 'architecture', 'development', 'testing', 'review', 'deployment'];
  const logs = project.logs || [];

  let completedPhases = 0;
  phases.forEach(phase => {
    if (logs.some(log => log.message.toLowerCase().includes(phase))) {
      completedPhases++;
    }
  });

  return Math.min((completedPhases / phases.length) * 100, 95);
}

function handleProjectComplete(data) {
  addActivityLog('system', `Project ${data.projectId} completed!`);
  updateCreationProgress(100);

  setTimeout(() => {
    hideCreationModal();
    loadProject(data.projectId);
  }, 1000);
}

function handleProjectError(data) {
  addActivityLog('system', `Error in project ${data.projectId}: ${data.error}`);
  hideCreationModal();
  alert('Project error: ' + data.error);
}

// ========== Event Listeners ==========
function setupEventListeners() {
  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + Enter to create project
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      if (document.getElementById('view-home').classList.contains('active')) {
        createProject();
      }
    }

    // Ctrl/Cmd + S to save
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      e.preventDefault();
      if (state.activeFile) {
        saveFile(state.activeFile, state.editor.getValue());
      }
    }
  });

  // Window resize
  window.addEventListener('resize', () => {
    if (state.editor) {
      state.editor.layout();
    }
  });
}

// Global functions for HTML onclick handlers
window.showView = showView;
window.toggleSidebar = toggleSidebar;
window.setPrompt = setPrompt;
window.createProject = createProject;
window.switchPanel = switchPanel;
window.refreshPreview = refreshPreview;
window.runTerminal = runTerminal;
window.toggleFolder = toggleFolder;
window.openFileByPath = openFileByPath;
window.closeFile = closeFile;
window.useTemplate = useTemplate;
window.showTemplates = () => showView('templates');
window.showHelp = () => alert('AlphaForge Ultra Help\n\n1. Describe your project idea\n2. Select build mode\n3. Click Build Now\n4. Watch AI agents work\n5. Edit and deploy!');
window.showSettings = () => alert('Settings coming soon!');
window.newFile = () => alert('New file coming soon!');
window.newFolder = () => alert('New folder coming soon!');
window.refreshFiles = () => {
  if (state.currentProject) {
    loadProjectFiles(state.currentProject);
  }
};
