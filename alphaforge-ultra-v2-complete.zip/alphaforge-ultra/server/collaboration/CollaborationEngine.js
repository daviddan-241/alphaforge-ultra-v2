import { EventEmitter } from 'events';

/**
 * Real-time Collaboration Engine
 * Manages multiple users editing same project
 */
export class CollaborationEngine extends EventEmitter {
  constructor() {
    super();
    this.rooms = new Map(); // projectId -> { users, cursors, operations }
    this.userSockets = new Map(); // socketId -> { userId, projectId }
  }

  joinRoom(socket, projectId, userData) {
    socket.join(`project:${projectId}`);

    if (!this.rooms.has(projectId)) {
      this.rooms.set(projectId, {
        users: new Map(),
        cursors: new Map(),
        operations: [],
        lastModified: Date.now()
      });
    }

    const room = this.rooms.get(projectId);
    const userId = userData.id || socket.id;

    room.users.set(userId, {
      socketId: socket.id,
      ...userData,
      joinedAt: Date.now()
    });

    this.userSockets.set(socket.id, { userId, projectId });

    // Notify others
    socket.to(`project:${projectId}`).emit('user:joined', {
      userId,
      ...userData
    });

    // Send current users to new user
    socket.emit('room:users', Array.from(room.users.values()));

    this.emit('user:joined', { projectId, userId, userData });
  }

  leaveRoom(socket) {
    const userData = this.userSockets.get(socket.id);
    if (!userData) return;

    const { userId, projectId } = userData;
    const room = this.rooms.get(projectId);

    if (room) {
      room.users.delete(userId);
      room.cursors.delete(userId);

      // Cleanup empty rooms
      if (room.users.size === 0) {
        this.rooms.delete(projectId);
      }
    }

    this.userSockets.delete(socket.id);

    // Notify others
    socket.to(`project:${projectId}`).emit('user:left', { userId });
    this.emit('user:left', { projectId, userId });
  }

  updateCursor(socket, data) {
    const userData = this.userSockets.get(socket.id);
    if (!userData) return;

    const { userId, projectId } = userData;
    const room = this.rooms.get(projectId);

    if (room) {
      room.cursors.set(userId, {
        ...data,
        timestamp: Date.now()
      });

      // Broadcast to others
      socket.to(`project:${projectId}`).emit('cursor:update', {
        userId,
        ...data
      });
    }
  }

  applyOperation(socket, operation) {
    const userData = this.userSockets.get(socket.id);
    if (!userData) return;

    const { projectId } = userData;
    const room = this.rooms.get(projectId);

    if (room) {
      room.operations.push({
        ...operation,
        timestamp: Date.now()
      });
      room.lastModified = Date.now();

      // Broadcast to others (not sender)
      socket.to(`project:${projectId}`).emit('operation', operation);
    }
  }

  sendChatMessage(socket, message) {
    const userData = this.userSockets.get(socket.id);
    if (!userData) return;

    const { userId, projectId } = userData;

    socket.to(`project:${projectId}`).emit('chat:message', {
      userId,
      message,
      timestamp: Date.now()
    });
  }

  getRoomInfo(projectId) {
    return this.rooms.get(projectId);
  }
}

export default CollaborationEngine;
