import { BaseAgent } from './BaseAgent.js';

export class DeployAgent extends BaseAgent {
  constructor() {
    super({
      name: 'DeployAgent',
      model: 'gpt-4o-mini',
      maxIterations: 10
    });
  }

  getRoleDescription() {
    return 'deploy applications to production. You configure hosting, set up domains, manage environment variables, and ensure smooth deployments';
  }

  initializeTools() {
    super.initializeTools();

    this.registerTool('deploy_static', {
      description: 'Deploy static site',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string' },
          domain: { type: 'string' }
        },
        required: ['path']
      },
      execute: async ({ path, domain }) => {
        return { 
          success: true, 
          url: `https://${domain || 'auto-generated'}.alphaforge.app`,
          type: 'static'
        };
      }
    });

    this.registerTool('deploy_container', {
      description: 'Deploy containerized app',
      parameters: {
        type: 'object',
        properties: {
          image: { type: 'string' },
          port: { type: 'number' },
          env: { type: 'object' }
        },
        required: ['image']
      },
      execute: async (params) => {
        return { 
          success: true, 
          url: 'https://app.alphaforge.app',
          type: 'container'
        };
      }
    });
  }

  async deploy(options) {
    return await this.execute({
      type: 'deploy',
      ...options
    });
  }
}

export default DeployAgent;
