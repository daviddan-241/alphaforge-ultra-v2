import { BaseAgent } from './BaseAgent.js';

export class ResearchAgent extends BaseAgent {
  constructor() {
    super({
      name: 'ResearchAgent',
      model: 'gpt-4o',
      maxIterations: 10
    });
  }

  getRoleDescription() {
    return 'research technologies, best practices, and solutions. You gather information from documentation, examples, and current trends';
  }

  async research(topic, options = {}) {
    return await this.execute({
      type: 'research',
      topic,
      ...options
    });
  }
}

export default ResearchAgent;
