import { BaseAgent } from './BaseAgent.js';

export class DesignAgent extends BaseAgent {
  constructor() {
    super({
      name: 'DesignAgent',
      model: 'gpt-4o',
      maxIterations: 15
    });
  }

  getRoleDescription() {
    return 'create UI/UX designs and generate visual assets. You design interfaces, create mockups, and ensure aesthetic quality';
  }

  initializeTools() {
    super.initializeTools();

    this.registerTool('generate_css', {
      description: 'Generate CSS/Tailwind styles',
      parameters: {
        type: 'object',
        properties: {
          component: { type: 'string' },
          theme: { type: 'string' },
          responsive: { type: 'boolean' }
        },
        required: ['component']
      },
      execute: async (params) => {
        return { success: true, styles: `/* Styles for ${params.component} */` };
      }
    });

    this.registerTool('create_mockup', {
      description: 'Create UI mockup description',
      parameters: {
        type: 'object',
        properties: {
          screen: { type: 'string' },
          components: { type: 'array', items: { type: 'string' } }
        },
        required: ['screen']
      },
      execute: async (params) => {
        return { success: true, mockup: `Mockup for ${params.screen}` };
      }
    });
  }
}

export default DesignAgent;
