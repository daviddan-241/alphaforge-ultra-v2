import { BaseAgent } from './BaseAgent.js';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export class TestAgent extends BaseAgent {
  constructor() {
    super({
      name: 'TestAgent',
      model: 'gpt-4o-mini',
      maxIterations: 15
    });
  }

  getRoleDescription() {
    return 'create and run tests. You generate unit tests, integration tests, and end-to-end tests. You use testing frameworks and ensure code coverage';
  }

  initializeTools() {
    super.initializeTools();

    this.registerTool('run_tests', {
      description: 'Run test suite',
      parameters: {
        type: 'object',
        properties: {
          command: { type: 'string' },
          cwd: { type: 'string' }
        },
        required: ['command']
      },
      execute: async ({ command, cwd }) => {
        try {
          const { stdout, stderr } = await execAsync(command, { cwd });
          return { success: true, output: stdout, errors: stderr };
        } catch (error) {
          return { success: false, error: error.message, output: error.stdout };
        }
      }
    });

    this.registerTool('generate_tests', {
      description: 'Generate test cases for code',
      parameters: {
        type: 'object',
        properties: {
          code: { type: 'string' },
          framework: { type: 'string', enum: ['jest', 'mocha', 'pytest'] }
        },
        required: ['code']
      },
      execute: async ({ code, framework = 'jest' }) => {
        // Test generation logic
        return { success: true, tests: `// ${framework} tests` };
      }
    });
  }

  async testProject(project) {
    return await this.execute({
      type: 'test_project',
      projectPath: project.path,
      techStack: project.context.techStack
    });
  }
}

export default TestAgent;
