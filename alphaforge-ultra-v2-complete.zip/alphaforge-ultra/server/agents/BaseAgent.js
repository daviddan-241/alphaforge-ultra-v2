import { EventEmitter } from 'events';
import OpenAI from 'openai';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs-extra';
import path from 'path';

/**
 * BaseAgent - Foundation for all specialized agents
 * Implements TAO Loop: Think → Act → Observe
 * Supports function calling, sub-agents, and autonomous execution
 */
export class BaseAgent extends EventEmitter {
  constructor(config = {}) {
    super();
    this.id = uuidv4();
    this.name = config.name || 'BaseAgent';
    this.model = config.model || 'gpt-4o-mini';
    this.maxIterations = config.maxIterations || 10;
    this.tools = new Map();
    this.memory = [];
    this.subAgents = new Map();

    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY
    });

    this.initializeTools();
  }

  /**
   * Initialize default tools available to all agents
   */
  initializeTools() {
    this.registerTool('read_file', {
      description: 'Read content of a file',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'File path to read' }
        },
        required: ['path']
      },
      execute: async ({ path: filePath }) => {
        try {
          const content = await fs.readFile(filePath, 'utf8');
          return { success: true, content };
        } catch (error) {
          return { success: false, error: error.message };
        }
      }
    });

    this.registerTool('write_file', {
      description: 'Write content to a file',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'File path to write' },
          content: { type: 'string', description: 'Content to write' }
        },
        required: ['path', 'content']
      },
      execute: async ({ path: filePath, content }) => {
        try {
          await fs.ensureDir(path.dirname(filePath));
          await fs.writeFile(filePath, content, 'utf8');
          return { success: true, message: `File written: ${filePath}` };
        } catch (error) {
          return { success: false, error: error.message };
        }
      }
    });

    this.registerTool('list_files', {
      description: 'List files in a directory',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'Directory path' },
          recursive: { type: 'boolean', description: 'List recursively' }
        },
        required: ['path']
      },
      execute: async ({ path: dirPath, recursive = false }) => {
        try {
          const files = await fs.readdir(dirPath, { recursive });
          return { success: true, files };
        } catch (error) {
          return { success: false, error: error.message };
        }
      }
    });

    this.registerTool('execute_code', {
      description: 'Execute code in sandbox',
      parameters: {
        type: 'object',
        properties: {
          code: { type: 'string', description: 'Code to execute' },
          language: { type: 'string', enum: ['javascript', 'python', 'bash'] }
        },
        required: ['code', 'language']
      },
      execute: async ({ code, language }) => {
        // This will be implemented in sandbox.js
        return { success: true, output: 'Code execution placeholder' };
      }
    });

    this.registerTool('spawn_subagent', {
      description: 'Spawn a specialized sub-agent for a specific task',
      parameters: {
        type: 'object',
        properties: {
          agentType: { type: 'string', description: 'Type of sub-agent to spawn' },
          task: { type: 'string', description: 'Task description for sub-agent' },
          context: { type: 'object', description: 'Context to pass to sub-agent' }
        },
        required: ['agentType', 'task']
      },
      execute: async ({ agentType, task, context = {} }) => {
        return await this.spawnSubAgent(agentType, task, context);
      }
    });

    this.registerTool('web_search', {
      description: 'Search the web for information',
      parameters: {
        type: 'object',
        properties: {
          query: { type: 'string', description: 'Search query' }
        },
        required: ['query']
      },
      execute: async ({ query }) => {
        // Placeholder for web search implementation
        return { success: true, results: [] };
      }
    });
  }

  registerTool(name, toolConfig) {
    this.tools.set(name, toolConfig);
  }

  /**
   * Main execution loop - TAO Pattern
   * Think → Act → Observe → Repeat
   */
  async execute(task) {
    this.emit('progress', { agent: this.name, status: 'started', task });

    const messages = [
      {
        role: 'system',
        content: this.getSystemPrompt()
      },
      {
        role: 'user',
        content: `Task: ${JSON.stringify(task, null, 2)}`
      }
    ];

    let iteration = 0;
    let completed = false;
    let finalResult = null;

    while (!completed && iteration < this.maxIterations) {
      iteration++;
      this.emit('progress', { agent: this.name, status: 'thinking', iteration });

      try {
        // THINK: Get model's decision
        const response = await this.openai.chat.completions.create({
          model: this.model,
          messages: messages,
          tools: this.getToolsSchema(),
          tool_choice: 'auto',
          temperature: 0.7,
          max_tokens: 4000
        });

        const message = response.choices[0].message;

        // Check if agent wants to use tools
        if (message.tool_calls && message.tool_calls.length > 0) {
          // ACT: Execute tools
          messages.push(message);

          for (const toolCall of message.tool_calls) {
            const toolName = toolCall.function.name;
            const toolArgs = JSON.parse(toolCall.function.arguments);

            this.emit('progress', { 
              agent: this.name, 
              status: 'acting', 
              tool: toolName,
              args: toolArgs 
            });

            // Execute the tool
            const toolResult = await this.executeTool(toolName, toolArgs);

            // OBSERVE: Add result to context
            messages.push({
              role: 'tool',
              tool_call_id: toolCall.id,
              content: JSON.stringify(toolResult)
            });

            this.emit('progress', { 
              agent: this.name, 
              status: 'observed', 
              tool: toolName,
              result: toolResult 
            });
          }
        } else {
          // Agent completed the task
          completed = true;
          finalResult = {
            success: true,
            output: message.content,
            iterations: iteration,
            agent: this.name
          };
        }

      } catch (error) {
        this.emit('error', { agent: this.name, error: error.message });
        return {
          success: false,
          error: error.message,
          iterations: iteration
        };
      }
    }

    if (!completed) {
      finalResult = {
        success: false,
        error: 'Max iterations reached',
        iterations: iteration
      };
    }

    this.emit('complete', { agent: this.name, result: finalResult });
    return finalResult;
  }

  async executeTool(toolName, args) {
    const tool = this.tools.get(toolName);
    if (!tool) {
      return { success: false, error: `Tool not found: ${toolName}` };
    }

    try {
      return await tool.execute(args);
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  getToolsSchema() {
    const tools = [];
    for (const [name, config] of this.tools) {
      tools.push({
        type: 'function',
        function: {
          name,
          description: config.description,
          parameters: config.parameters
        }
      });
    }
    return tools;
  }

  getSystemPrompt() {
    return `You are ${this.name}, an expert AI software engineering agent.
Your role is to ${this.getRoleDescription()}.

You work in a TAO loop (Think-Act-Observe):
1. THINK: Analyze the task and decide next steps
2. ACT: Use available tools to make progress
3. OBSERVE: Review results and adapt your approach

Available tools:
${Array.from(this.tools.keys()).join(', ')}

Rules:
- Break complex tasks into smaller steps
- Use tools to interact with the file system and execute code
- Spawn sub-agents for parallel tasks when beneficial
- Always verify your work before completing
- If you encounter errors, attempt to fix them

Respond with your reasoning, then use tools to act.`;
  }

  getRoleDescription() {
    return 'assist with software development tasks';
  }

  /**
   * Spawn a sub-agent for parallel task execution
   */
  async spawnSubAgent(agentType, task, context) {
    this.emit('subtask', { 
      parent: this.name, 
      agentType, 
      task,
      context 
    });

    // Sub-agent implementation would create new agent instance
    // For now, return placeholder
    return {
      success: true,
      message: `Sub-agent ${agentType} spawned for: ${task}`,
      result: 'Sub-agent execution placeholder'
    };
  }

  /**
   * Add memory/context to the agent
   */
  addMemory(memory) {
    this.memory.push({
      timestamp: new Date().toISOString(),
      content: memory
    });
  }

  /**
   * Get relevant memories for current context
   */
  getRelevantMemories(query, limit = 5) {
    // Simple implementation - in production, use vector search
    return this.memory.slice(-limit);
  }
}

export default BaseAgent;
