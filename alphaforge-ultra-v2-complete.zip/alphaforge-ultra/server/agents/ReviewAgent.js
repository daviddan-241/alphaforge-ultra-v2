import { BaseAgent } from './BaseAgent.js';

export class ReviewAgent extends BaseAgent {
  constructor() {
    super({
      name: 'ReviewAgent',
      model: 'gpt-4o',
      maxIterations: 10
    });
  }

  getRoleDescription() {
    return 'review code for quality, security, and best practices. You perform code reviews, suggest improvements, and ensure standards compliance';
  }

  async reviewCode(project) {
    return await this.execute({
      type: 'review_code',
      projectPath: project.path,
      files: Array.from(project.context.files.keys())
    });
  }
}

export default ReviewAgent;
