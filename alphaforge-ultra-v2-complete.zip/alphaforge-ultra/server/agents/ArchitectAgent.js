import { BaseAgent } from './BaseAgent.js';

export class ArchitectAgent extends BaseAgent {
  constructor() {
    super({
      name: 'ArchitectAgent',
      model: 'gpt-4o',
      maxIterations: 15
    });
  }

  getRoleDescription() {
    return 'design software architecture and system structure. You analyze requirements and create comprehensive technical designs including component diagrams, data models, API specifications, and technology stack recommendations';
  }

  async createPlan(prompt, projectId) {
    return await this.execute({
      type: 'create_plan',
      prompt,
      projectId
    });
  }

  async design(options) {
    return await this.execute({
      type: 'design_architecture',
      ...options
    });
  }
}

export default ArchitectAgent;
