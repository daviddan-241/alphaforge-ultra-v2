import { BaseAgent } from './BaseAgent.js';

export class PerformanceAgent extends BaseAgent {
  constructor() {
    super({
      name: 'PerformanceAgent',
      model: 'gpt-4o-mini',
      maxIterations: 10
    });
  }

  getRoleDescription() {
    return 'optimize code performance. You identify bottlenecks, suggest improvements, and ensure efficient resource usage';
  }

  async optimize(project) {
    return await this.execute({
      type: 'optimize',
      projectPath: project.path
    });
  }
}

export default PerformanceAgent;
