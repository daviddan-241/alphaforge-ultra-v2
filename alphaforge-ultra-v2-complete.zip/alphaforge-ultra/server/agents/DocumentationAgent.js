import { BaseAgent } from './BaseAgent.js';

export class DocumentationAgent extends BaseAgent {
  constructor() {
    super({
      name: 'DocumentationAgent',
      model: 'gpt-4o-mini',
      maxIterations: 10
    });
  }

  getRoleDescription() {
    return 'create comprehensive documentation. You write READMEs, API docs, inline comments, and user guides';
  }

  async generateDocs(project) {
    return await this.execute({
      type: 'generate_docs',
      projectPath: project.path,
      files: Array.from(project.context.files.keys())
    });
  }
}

export default DocumentationAgent;
