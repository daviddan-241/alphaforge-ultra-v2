import { BaseAgent } from './BaseAgent.js';

export class CodeGeneratorAgent extends BaseAgent {
  constructor() {
    super({
      name: 'CodeGeneratorAgent',
      model: 'gpt-4o',
      maxIterations: 20
    });
  }

  getRoleDescription() {
    return 'write production-quality code. You implement features, create components, build APIs, and ensure code follows best practices. You write clean, documented, and tested code';
  }

  initializeTools() {
    super.initializeTools();

    this.registerTool('generate_component', {
      description: 'Generate a React/Vue component',
      parameters: {
        type: 'object',
        properties: {
          name: { type: 'string' },
          type: { type: 'string', enum: ['react', 'vue', 'svelte'] },
          props: { type: 'array', items: { type: 'string' } },
          styling: { type: 'string', enum: ['css', 'tailwind', 'styled'] }
        },
        required: ['name', 'type']
      },
      execute: async (params) => {
        // Component generation logic
        return { success: true, component: `// Generated ${params.name}` };
      }
    });

    this.registerTool('generate_api', {
      description: 'Generate API endpoint',
      parameters: {
        type: 'object',
        properties: {
          method: { type: 'string', enum: ['GET', 'POST', 'PUT', 'DELETE'] },
          path: { type: 'string' },
          handler: { type: 'string' }
        },
        required: ['method', 'path']
      },
      execute: async (params) => {
        return { success: true, endpoint: `// ${params.method} ${params.path}` };
      }
    });
  }
}

export default CodeGeneratorAgent;
