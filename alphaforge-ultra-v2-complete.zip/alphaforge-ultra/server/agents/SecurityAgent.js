import { BaseAgent } from './BaseAgent.js';

export class SecurityAgent extends BaseAgent {
  constructor() {
    super({
      name: 'SecurityAgent',
      model: 'gpt-4o',
      maxIterations: 10
    });
  }

  getRoleDescription() {
    return 'audit code for security vulnerabilities. You check for OWASP top 10, injection attacks, insecure dependencies, and best practices';
  }

  initializeTools() {
    super.initializeTools();

    this.registerTool('scan_vulnerabilities', {
      description: 'Scan code for security issues',
      parameters: {
        type: 'object',
        properties: {
          code: { type: 'string' },
          language: { type: 'string' }
        },
        required: ['code']
      },
      execute: async ({ code }) => {
        return { success: true, issues: [], score: 95 };
      }
    });
  }
}

export default SecurityAgent;
