import { BaseAgent } from './BaseAgent.js';

export class DebugAgent extends BaseAgent {
  constructor() {
    super({
      name: 'DebugAgent',
      model: 'gpt-4o-mini',
      maxIterations: 10
    });
  }

  getRoleDescription() {
    return 'identify and fix bugs in code. You analyze error messages, trace execution, and apply fixes. You use debugging tools and systematic approaches';
  }

  async fixBug(project, failure) {
    return await this.execute({
      type: 'fix_bug',
      project,
      failure
    });
  }
}

export default DebugAgent;
