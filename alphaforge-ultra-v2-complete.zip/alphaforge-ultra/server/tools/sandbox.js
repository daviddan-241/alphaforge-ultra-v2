import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs-extra';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';

const execAsync = promisify(exec);
const EXECUTION_TIMEOUT = 30000; // 30 seconds

/**
 * Secure Code Execution Sandbox
 * Supports multiple languages with resource limits
 */
export async function executeCode(code, language = 'javascript', options = {}) {
  const executionId = uuidv4().slice(0, 8);
  const tempDir = path.join(process.cwd(), 'uploads', `exec-${executionId}`);

  try {
    await fs.ensureDir(tempDir);

    let command;
    let fileName;

    switch (language.toLowerCase()) {
      case 'javascript':
      case 'js':
      case 'node':
        fileName = 'script.js';
        await fs.writeFile(path.join(tempDir, fileName), code);
        command = `cd "${tempDir}" && node ${fileName}`;
        break;

      case 'typescript':
      case 'ts':
        fileName = 'script.ts';
        await fs.writeFile(path.join(tempDir, fileName), code);
        command = `cd "${tempDir}" && npx ts-node ${fileName}`;
        break;

      case 'python':
      case 'py':
        fileName = 'script.py';
        await fs.writeFile(path.join(tempDir, fileName), code);
        command = `cd "${tempDir}" && python3 ${fileName}`;
        break;

      case 'bash':
      case 'shell':
      case 'sh':
        fileName = 'script.sh';
        await fs.writeFile(path.join(tempDir, fileName), code);
        await fs.chmod(path.join(tempDir, fileName), 0o755);
        command = `cd "${tempDir}" && bash ${fileName}`;
        break;

      case 'html':
        // For HTML, return it as-is for preview
        return {
          success: true,
          output: code,
          type: 'html',
          executionId
        };

      default:
        return {
          success: false,
          error: `Unsupported language: ${language}`,
          executionId
        };
    }

    // Execute with timeout and resource limits
    const { stdout, stderr } = await execAsync(command, {
      timeout: EXECUTION_TIMEOUT,
      maxBuffer: 1024 * 1024, // 1MB output limit
      env: {
        ...process.env,
        NODE_OPTIONS: '--max-old-space-size=512', // Limit memory
        PYTHONPATH: tempDir
      }
    });

    // Cleanup
    await fs.remove(tempDir);

    return {
      success: true,
      output: stdout,
      error: stderr || null,
      executionId,
      language
    };

  } catch (error) {
    // Cleanup on error
    try {
      await fs.remove(tempDir);
    } catch (e) {}

    return {
      success: false,
      error: error.message,
      output: error.stdout || '',
      stderr: error.stderr || '',
      executionId,
      language
    };
  }
}

/**
 * Install npm packages in temp directory
 */
export async function installPackages(packages, cwd) {
  try {
    const packageList = Array.isArray(packages) ? packages.join(' ') : packages;
    const { stdout, stderr } = await execAsync(
      `npm install ${packageList}`,
      { cwd, timeout: 60000 }
    );

    return {
      success: true,
      output: stdout,
      error: stderr
    };
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}

/**
 * Run tests in project directory
 */
export async function runTests(testCommand, cwd) {
  try {
    const { stdout, stderr } = await execAsync(testCommand, {
      cwd,
      timeout: 60000,
      env: { ...process.env, CI: 'true' }
    });

    return {
      success: true,
      output: stdout,
      error: stderr,
      passed: !stderr.includes('FAIL') && !stdout.includes('failed')
    };
  } catch (error) {
    return {
      success: false,
      error: error.message,
      output: error.stdout,
      stderr: error.stderr,
      passed: false
    };
  }
}

export default { executeCode, installPackages, runTests };
