import fs from 'fs-extra';
import path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

/**
 * Deployment Manager
 * Handles various deployment targets
 */
export class DeploymentManager {
  constructor() {
    this.deployments = new Map();
  }

  /**
   * Deploy static site
   */
  async deployStatic(projectPath, options = {}) {
    const deployId = Date.now().toString(36);
    const deployPath = path.join(process.cwd(), 'deployments', 'static', deployId);

    try {
      // Copy files
      await fs.copy(projectPath, deployPath);

      // Build if needed
      if (await fs.pathExists(path.join(deployPath, 'package.json'))) {
        try {
          await execAsync('npm install && npm run build', {
            cwd: deployPath,
            timeout: 120000
          });
        } catch (e) {
          console.log('Build skipped or failed:', e.message);
        }
      }

      const deployment = {
        id: deployId,
        type: 'static',
        url: `/deploy/static/${deployId}`,
        path: deployPath,
        createdAt: new Date().toISOString(),
        ...options
      };

      this.deployments.set(deployId, deployment);

      return {
        success: true,
        deployment
      };
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Deploy containerized app
   */
  async deployContainer(projectPath, options = {}) {
    const deployId = Date.now().toString(36);

    try {
      // Create Dockerfile if not exists
      const dockerfilePath = path.join(projectPath, 'Dockerfile');
      if (!await fs.pathExists(dockerfilePath)) {
        const dockerfile = this.generateDockerfile(options);
        await fs.writeFile(dockerfilePath, dockerfile);
      }

      // Build and run container
      const imageName = `alphaforge-${deployId}`;
      await execAsync(`docker build -t ${imageName} .`, {
        cwd: projectPath,
        timeout: 300000
      });

      const port = options.port || 3000;
      await execAsync(`docker run -d -p ${port}:${port} --name ${imageName} ${imageName}`, {
        timeout: 30000
      });

      const deployment = {
        id: deployId,
        type: 'container',
        url: `http://localhost:${port}`,
        containerName: imageName,
        port,
        createdAt: new Date().toISOString(),
        ...options
      };

      this.deployments.set(deployId, deployment);

      return {
        success: true,
        deployment
      };
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Generate Dockerfile based on project type
   */
  generateDockerfile(options) {
    const { type = 'node', port = 3000 } = options;

    if (type === 'node') {
      return `FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE ${port}
CMD ["npm", "start"]`;
    }

    if (type === 'python') {
      return `FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE ${port}
CMD ["python", "app.py"]`;
    }

    return `FROM nginx:alpine
COPY . /usr/share/nginx/html
EXPOSE 80`;
  }

  /**
   * Get deployment info
   */
  getDeployment(deployId) {
    return this.deployments.get(deployId);
  }

  /**
   * List all deployments
   */
  listDeployments() {
    return Array.from(this.deployments.values());
  }

  /**
   * Stop deployment
   */
  async stopDeployment(deployId) {
    const deployment = this.deployments.get(deployId);
    if (!deployment) return { success: false, error: 'Deployment not found' };

    try {
      if (deployment.type === 'container') {
        await execAsync(`docker stop ${deployment.containerName} && docker rm ${deployment.containerName}`);
      }

      deployment.status = 'stopped';
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }
}

export default DeploymentManager;
