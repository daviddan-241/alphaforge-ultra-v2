import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { createServer } from 'http';
import { Server } from 'socket.io';
import path from 'path';
import fs from 'fs-extra';
import { v4 as uuidv4 } from 'uuid';

import { AlphaForgeOrchestrator } from './Orchestrator.js';
import { executeCode } from './tools/sandbox.js';

dotenv.config();

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

const orchestrator = new AlphaForgeOrchestrator();

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.resolve('client')));

// Ensure directories exist
fs.ensureDirSync('projects');
fs.ensureDirSync('uploads');

// ============ REST API ============

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    version: '2.0.0-ultra'
  });
});

// Create new project
app.post('/api/projects', async (req, res) => {
  try {
    const { prompt, options = {} } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const projectId = await orchestrator.createProject(prompt, {
      mode: options.mode || 'autonomous',
      autonomy: options.autonomy || 'high'
    });

    res.json({ 
      success: true, 
      projectId,
      message: 'Project created and agents started'
    });

  } catch (error) {
    console.error('Create project error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get project status
app.get('/api/projects/:id', (req, res) => {
  const project = orchestrator.getProjectStatus(req.params.id);
  if (!project) {
    return res.status(404).json({ error: 'Project not found' });
  }

  res.json({
    id: project.id,
    status: project.status,
    prompt: project.prompt,
    mode: project.mode,
    createdAt: project.createdAt,
    logs: project.logs.slice(-50), // Last 50 logs
    agents: Array.from(project.agents.entries()).map(([id, agent]) => ({
      id,
      ...agent
    })),
    artifacts: project.artifacts
  });
});

// Get project files
app.get('/api/projects/:id/files', async (req, res) => {
  try {
    const projectPath = path.join(process.cwd(), 'projects', req.params.id);

    if (!await fs.pathExists(projectPath)) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const files = {};
    const readDir = async (dir, basePath = '') => {
      const entries = await fs.readdir(dir, { withFileTypes: true });

      for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        const relativePath = path.join(basePath, entry.name);

        if (entry.isDirectory()) {
          await readDir(fullPath, relativePath);
        } else {
          try {
            const content = await fs.readFile(fullPath, 'utf8');
            files[relativePath] = content;
          } catch (e) {
            files[relativePath] = '[Binary file]';
          }
        }
      }
    };

    await readDir(projectPath);
    res.json({ files });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update file
app.put('/api/projects/:id/files/*', async (req, res) => {
  try {
    const filePath = req.params[0];
    const { content } = req.body;
    const fullPath = path.join(process.cwd(), 'projects', req.params.id, filePath);

    await fs.ensureDir(path.dirname(fullPath));
    await fs.writeFile(fullPath, content, 'utf8');

    res.json({ success: true, message: 'File updated' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Execute code
app.post('/api/execute', async (req, res) => {
  try {
    const { code, language = 'javascript' } = req.body;
    const result = await executeCode(code, language);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Stop project
app.post('/api/projects/:id/stop', async (req, res) => {
  try {
    await orchestrator.stopProject(req.params.id);
    res.json({ success: true, message: 'Project stopped' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// List all projects
app.get('/api/projects', (req, res) => {
  const projects = Array.from(orchestrator.activeProjects.entries()).map(([id, project]) => ({
    id,
    status: project.status,
    prompt: project.prompt.substring(0, 100) + '...',
    createdAt: project.createdAt
  }));

  res.json({ projects });
});

// ============ WebSocket Real-time Updates ============

io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);

  // Subscribe to project updates
  socket.on('subscribe', (projectId) => {
    socket.join(`project:${projectId}`);
    console.log(`Socket ${socket.id} subscribed to project ${projectId}`);
  });

  // Unsubscribe
  socket.on('unsubscribe', (projectId) => {
    socket.leave(`project:${projectId}`);
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
  });
});

// Forward orchestrator events to WebSocket
orchestrator.on('project:created', (data) => {
  io.emit('project:created', data);
});

orchestrator.on('project:log', (data) => {
  io.to(`project:${data.projectId}`).emit('project:log', data);
});

orchestrator.on('project:complete', (data) => {
  io.to(`project:${data.projectId}`).emit('project:complete', data);
});

orchestrator.on('project:error', (data) => {
  io.to(`project:${data.projectId}`).emit('project:error', data);
});

orchestrator.on('agent:progress', (data) => {
  // Broadcast to all connected clients for live agent monitoring
  io.emit('agent:progress', data);
});

orchestrator.on('agent:complete', (data) => {
  io.emit('agent:complete', data);
});

// ============ Start Server ============

const PORT = process.env.PORT || 3000;

httpServer.listen(PORT, () => {
  console.log(`
🚀 ╔════════════════════════════════════════════════════════════╗
🚀 ║                                                            ║
🚀 ║           ALPHAFORGE ULTRA v2.0 - AI ARMY ACTIVE          ║
🚀 ║                                                            ║
🚀 ║   🤖 11 Specialized Agents • 🔄 TAO Loop Architecture     ║
🚀 ║   ⚡ Real-time Collaboration • 🌐 WebSocket Live Updates   ║
🚀 ║                                                            ║
🚀 ╚════════════════════════════════════════════════════════════╝
  `);
  console.log(`📡 Server running on http://localhost:${PORT}`);
  console.log(`🎯 Open http://localhost:${PORT} to start building
`);
});

export default app;
