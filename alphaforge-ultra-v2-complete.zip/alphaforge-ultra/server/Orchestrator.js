import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs-extra';
import path from 'path';

// Import all specialized agents
import { ArchitectAgent } from './agents/ArchitectAgent.js';
import { CodeGeneratorAgent } from './agents/CodeGeneratorAgent.js';
import { DebugAgent } from './agents/DebugAgent.js';
import { TestAgent } from './agents/TestAgent.js';
import { ReviewAgent } from './agents/ReviewAgent.js';
import { DeployAgent } from './agents/DeployAgent.js';
import { ResearchAgent } from './agents/ResearchAgent.js';
import { DesignAgent } from './agents/DesignAgent.js';
import { SecurityAgent } from './agents/SecurityAgent.js';
import { PerformanceAgent } from './agents/PerformanceAgent.js';
import { DocumentationAgent } from './agents/DocumentationAgent.js';

/**
 * AlphaForge Ultra - Multi-Agent Orchestrator
 * Hierarchical architecture with specialized agents working in parallel
 */
export class AlphaForgeOrchestrator extends EventEmitter {
  constructor() {
    super();
    this.agents = new Map();
    this.activeProjects = new Map();
    this.agentRegistry = new Map();
    this.initializeAgents();
  }

  initializeAgents() {
    // Register all specialized agents
    this.registerAgent('architect', new ArchitectAgent());
    this.registerAgent('codegen', new CodeGeneratorAgent());
    this.registerAgent('debugger', new DebugAgent());
    this.registerAgent('tester', new TestAgent());
    this.registerAgent('reviewer', new ReviewAgent());
    this.registerAgent('deployer', new DeployAgent());
    this.registerAgent('researcher', new ResearchAgent());
    this.registerAgent('designer', new DesignAgent());
    this.registerAgent('security', new SecurityAgent());
    this.registerAgent('performance', new PerformanceAgent());
    this.registerAgent('documenter', new DocumentationAgent());
  }

  registerAgent(name, agentInstance) {
    this.agentRegistry.set(name, agentInstance);
    agentInstance.on('progress', (data) => this.handleAgentProgress(name, data));
    agentInstance.on('complete', (data) => this.handleAgentComplete(name, data));
    agentInstance.on('error', (data) => this.handleAgentError(name, data));
    agentInstance.on('subtask', (data) => this.handleSubTask(name, data));
  }

  /**
   * Main entry point - Start a new project
   */
  async createProject(userPrompt, options = {}) {
    const projectId = uuidv4();
    const projectPath = path.join(process.cwd(), 'projects', projectId);

    await fs.ensureDir(projectPath);

    const project = {
      id: projectId,
      prompt: userPrompt,
      path: projectPath,
      status: 'initializing',
      mode: options.mode || 'autonomous', // 'plan', 'lite', 'autonomous', 'max'
      autonomy: options.autonomy || 'high', // 'low', 'medium', 'high', 'max'
      artifacts: [],
      tasks: [],
      agents: new Map(),
      context: {
        requirements: null,
        architecture: null,
        techStack: null,
        files: new Map(),
        tests: [],
        deployment: null
      },
      createdAt: new Date().toISOString(),
      logs: []
    };

    this.activeProjects.set(projectId, project);
    this.emit('project:created', { projectId, prompt: userPrompt });

    // Start the orchestration based on mode
    if (options.mode === 'plan') {
      await this.runPlanMode(project);
    } else {
      await this.runAutonomousMode(project);
    }

    return projectId;
  }

  /**
   * Plan Mode: Create detailed plan before execution
   */
  async runPlanMode(project) {
    this.log(project.id, '🔍 Starting Plan Mode - Analyzing requirements...');

    const architect = this.agentRegistry.get('architect');
    const plan = await architect.createPlan(project.prompt, project.id);

    project.context.plan = plan;
    project.status = 'planning';

    this.emit('project:plan', { 
      projectId: project.id, 
      plan: plan 
    });

    return plan;
  }

  /**
   * Autonomous Mode: Full self-driving development
   */
  async runAutonomousMode(project) {
    this.log(project.id, '🚀 Starting Autonomous Mode - Full AI takeover initiated');
    project.status = 'running';

    try {
      // Phase 1: Research & Requirements
      await this.phaseResearch(project);

      // Phase 2: Architecture Design
      await this.phaseArchitecture(project);

      // Phase 3: Parallel Development (Design + Code + Security)
      await this.phaseParallelDevelopment(project);

      // Phase 4: Testing & Debugging Loop
      await this.phaseTesting(project);

      // Phase 5: Review & Optimization
      await this.phaseReview(project);

      // Phase 6: Deployment
      await this.phaseDeploy(project);

      // Phase 7: Documentation
      await this.phaseDocumentation(project);

      project.status = 'completed';
      this.emit('project:complete', { 
        projectId: project.id, 
        artifacts: project.artifacts 
      });

    } catch (error) {
      project.status = 'error';
      this.log(project.id, `❌ Error: ${error.message}`);
      this.emit('project:error', { projectId: project.id, error: error.message });
      throw error;
    }
  }

  /**
   * Phase 1: Research - Gather context and best practices
   */
  async phaseResearch(project) {
    this.log(project.id, '📚 Phase 1: Research - Gathering intelligence...');

    const researcher = this.agentRegistry.get('researcher');
    const research = await researcher.research(project.prompt, {
      techStack: true,
      bestPractices: true,
      similarProjects: true,
      apis: true
    });

    project.context.research = research;
    this.log(project.id, `✅ Research complete: ${research.findings.length} findings`);
  }

  /**
   * Phase 2: Architecture - Design system structure
   */
  async phaseArchitecture(project) {
    this.log(project.id, '🏗️ Phase 2: Architecture - Designing system...');

    const architect = this.agentRegistry.get('architect');
    const architecture = await architect.design({
      prompt: project.prompt,
      research: project.context.research,
      constraints: { scalability: true, security: true }
    });

    project.context.architecture = architecture;
    project.context.techStack = architecture.techStack;

    // Save architecture document
    await fs.writeFile(
      path.join(project.path, 'ARCHITECTURE.md'),
      architecture.documentation
    );

    this.log(project.id, `✅ Architecture designed: ${architecture.components.length} components`);
  }

  /**
   * Phase 3: Parallel Development - Multiple agents working simultaneously
   */
  async phaseParallelDevelopment(project) {
    this.log(project.id, '⚡ Phase 3: Parallel Development - Agents working simultaneously...');

    const tasks = [];

    // Designer creates UI/UX
    tasks.push(this.runAgentTask(project, 'designer', {
      type: 'create_design',
      architecture: project.context.architecture,
      prompt: project.prompt
    }));

    // Security agent audits requirements
    tasks.push(this.runAgentTask(project, 'security', {
      type: 'security_audit',
      architecture: project.context.architecture
    }));

    // Code generator builds core functionality
    tasks.push(this.runAgentTask(project, 'codegen', {
      type: 'generate_code',
      architecture: project.context.architecture,
      techStack: project.context.techStack
    }));

    // Wait for all parallel tasks
    const results = await Promise.allSettled(tasks);

    // Merge results
    for (const result of results) {
      if (result.status === 'fulfilled') {
        this.mergeAgentOutput(project, result.value);
      }
    }

    this.log(project.id, '✅ Parallel development phase complete');
  }

  /**
   * Phase 4: Testing & Debugging - Self-healing code
   */
  async phaseTesting(project) {
    this.log(project.id, '🧪 Phase 4: Testing & Debugging - Ensuring quality...');

    const tester = this.agentRegistry.get('tester');
    const debugger_ = this.agentRegistry.get('debugger');

    let attempts = 0;
    const maxAttempts = 5;
    let allTestsPass = false;

    while (!allTestsPass && attempts < maxAttempts) {
      attempts++;
      this.log(project.id, `🔄 Testing iteration ${attempts}/${maxAttempts}`);

      // Generate and run tests
      const testResults = await tester.testProject(project);

      if (testResults.success) {
        allTestsPass = true;
        this.log(project.id, '✅ All tests passed!');
      } else {
        this.log(project.id, `❌ ${testResults.failures.length} tests failed, auto-fixing...`);

        // Auto-fix failures
        for (const failure of testResults.failures) {
          await debugger_.fixBug(project, failure);
        }
      }
    }

    project.context.tests = testResults;
  }

  /**
   * Phase 5: Review & Optimization
   */
  async phaseReview(project) {
    this.log(project.id, '👁️ Phase 5: Review & Optimization - Polishing...');

    const reviewer = this.agentRegistry.get('reviewer');
    const performance = this.agentRegistry.get('performance');

    // Code review
    const review = await reviewer.reviewCode(project);

    // Performance optimization
    const optimization = await performance.optimize(project);

    if (optimization.suggestions.length > 0) {
      this.log(project.id, `⚡ Applied ${optimization.suggestions.length} performance optimizations`);
    }

    project.context.review = review;
  }

  /**
   * Phase 6: Deployment
   */
  async phaseDeploy(project) {
    this.log(project.id, '🚀 Phase 6: Deployment - Going live...');

    const deployer = this.agentRegistry.get('deployer');

    const deployment = await deployer.deploy({
      project: project,
      type: 'autoscale', // 'static', 'autoscale', 'reserved'
      domain: null // auto-generated
    });

    project.context.deployment = deployment;
    project.artifacts.push({
      type: 'deployment',
      url: deployment.url,
      timestamp: new Date().toISOString()
    });

    this.log(project.id, `🌐 Deployed to: ${deployment.url}`);
  }

  /**
   * Phase 7: Documentation
   */
  async phaseDocumentation(project) {
    this.log(project.id, '📝 Phase 7: Documentation - Creating docs...');

    const documenter = this.agentRegistry.get('documenter');

    await documenter.generateDocs(project);
    this.log(project.id, '✅ Documentation generated');
  }

  /**
   * Run a specific agent task with timeout and error handling
   */
  async runAgentTask(project, agentName, task) {
    const agent = this.agentRegistry.get(agentName);
    const taskId = uuidv4();

    project.agents.set(taskId, {
      agent: agentName,
      status: 'running',
      startTime: Date.now()
    });

    try {
      const result = await agent.execute({
        ...task,
        projectId: project.id,
        projectPath: project.path,
        context: project.context
      });

      project.agents.set(taskId, {
        agent: agentName,
        status: 'completed',
        endTime: Date.now()
      });

      return result;
    } catch (error) {
      project.agents.set(taskId, {
        agent: agentName,
        status: 'error',
        error: error.message
      });
      throw error;
    }
  }

  mergeAgentOutput(project, output) {
    if (output.files) {
      for (const [filename, content] of Object.entries(output.files)) {
        project.context.files.set(filename, content);
      }
    }
    if (output.artifacts) {
      project.artifacts.push(...output.artifacts);
    }
  }

  log(projectId, message) {
    const project = this.activeProjects.get(projectId);
    if (project) {
      const logEntry = {
        timestamp: new Date().toISOString(),
        message
      };
      project.logs.push(logEntry);
      this.emit('project:log', { projectId, log: logEntry });
      console.log(`[${projectId}] ${message}`);
    }
  }

  handleAgentProgress(agentName, data) {
    this.emit('agent:progress', { agent: agentName, ...data });
  }

  handleAgentComplete(agentName, data) {
    this.emit('agent:complete', { agent: agentName, ...data });
  }

  handleAgentError(agentName, data) {
    this.emit('agent:error', { agent: agentName, ...data });
  }

  handleSubTask(parentAgent, data) {
    // Spawn sub-agent for specific task
    this.emit('agent:subtask', { parent: parentAgent, ...data });
  }

  getProjectStatus(projectId) {
    return this.activeProjects.get(projectId);
  }

  async stopProject(projectId) {
    const project = this.activeProjects.get(projectId);
    if (project) {
      project.status = 'stopped';
      // Cancel all running agents
      for (const [taskId, task] of project.agents) {
        if (task.status === 'running') {
          task.status = 'cancelled';
        }
      }
      this.emit('project:stopped', { projectId });
    }
  }
}

export default AlphaForgeOrchestrator;
