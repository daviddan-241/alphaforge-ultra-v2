@echo off
echo 🚀 AlphaForge Ultra Setup
echo ==========================

REM Check Node.js
node --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Node.js not found. Please install Node.js 18+
    exit /b 1
)

echo ✅ Node.js found

REM Install dependencies
echo 📦 Installing dependencies...
call npm install

REM Setup environment
echo 🔧 Setting up environment...
if not exist .env (
    copy .env.example .env
    echo ⚠️  Please edit .env and add your OPENAI_API_KEY
)

REM Create directories
if not exist projects mkdir projects
if not exist uploads mkdir uploads
if not exist deployments\static mkdir deployments\static

echo.
echo ✨ Setup complete!
echo 📝 Next steps:
echo    1. Edit .env and add your OPENAI_API_KEY
echo    2. Run: npm start
echo    3. Open: http://localhost:3000
pause
