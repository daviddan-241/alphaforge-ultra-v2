#!/bin/bash
# AlphaForge Ultra - Quick Setup Script

echo "🚀 AlphaForge Ultra Setup"
echo "=========================="

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js 18+"
    exit 1
fi

echo "✅ Node.js found: $(node --version)"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Setup environment
echo "🔧 Setting up environment..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "⚠️  Please edit .env and add your OPENAI_API_KEY"
fi

# Create directories
mkdir -p projects uploads deployments/static

# Check Docker (optional)
if command -v docker &> /dev/null; then
    echo "✅ Docker found (optional, for containerized deployments)"
else
    echo "⚠️  Docker not found (optional)"
fi

echo ""
echo "✨ Setup complete!"
echo "📝 Next steps:"
echo "   1. Edit .env and add your OPENAI_API_KEY"
echo "   2. Run: npm start"
echo "   3. Open: http://localhost:3000"
echo ""
echo "🎯 Features:"
echo "   • 11 AI Agents working in parallel"
echo "   • Real-time collaboration"
echo "   • Monaco Editor (VS Code)"
echo "   • Multi-language sandbox"
echo "   • One-click deployment"
